package com.cognizant.pensiondetail.exception;

import lombok.NoArgsConstructor;

/**
 * Invalid Aadhar Number Exception
 * 
 * @author murali
 */
@NoArgsConstructor
public class InvalidAadhaarException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
