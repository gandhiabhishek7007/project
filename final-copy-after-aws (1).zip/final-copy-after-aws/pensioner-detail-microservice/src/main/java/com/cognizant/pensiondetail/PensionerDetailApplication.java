package com.cognizant.pensiondetail;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import lombok.NoArgsConstructor;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Main and Swagger functions for Pensioner Detail MS
 * 
 * @author Murali
 *
 */

@EnableSwagger2
@NoArgsConstructor
@SpringBootApplication
public class PensionerDetailApplication {

	/**
	 * Main function
	 * 
	 * @param args
	 */
	public static void main(final String[] args) {
		SpringApplication.run(PensionerDetailApplication.class, args);
	}

	/**
	 * Bean for Swagger Configuration
	 * 
	 * @return - Swagger Docket
	 */
	@Bean
	public Docket swaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.cognizant.pensiondetail")).build().apiInfo(apiDetails());

	}

	/**
	 * 
	 * @return Api information
	 */
	private ApiInfo apiDetails() {

		return new ApiInfo("Pension Detail Service", "Microservice Form Pension Management Project", "1.0",
				"Free To Use", new springfox.documentation.service.Contact("${service.contact.name}", "", "${service.contact.mail}"),
				"API Licesence", "....", Collections.emptyList());
	}
}
