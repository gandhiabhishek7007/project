package com.cognizant.pensiondetail.repository;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.cognizant.pensiondetail.filereader.CSVFileReader;
import com.cognizant.pensiondetail.model.BankDetail;
import com.cognizant.pensiondetail.model.PensionerDetail;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author murali
 *
 */

@Repository
@NoArgsConstructor
@Slf4j
@Configuration
@PropertySource("classpath:messages.properties")
public class PensionRepositoryImpl implements PensionRepository {

	/** Autowired to properties file */
	@Autowired
	private Environment env;
	
	/** Autowired to file reader*/
	@Autowired
	private CSVFileReader read;
	
	/**
	 * Reads csv file and returns List<PensionerDetail>
	 */
	@Override
	public List<PensionerDetail> readAllCsvData() throws IOException, ParseException {
		
		log.debug(env.getProperty("repo.message"));
		
		List<PensionerDetail> alldetails = new ArrayList<>();

		final BufferedReader reader = read.getBufferReader();

		String[] temp;
		String line;

		Date date1;
		BankDetail bankDetail;
		PensionerDetail detail;

		while ((line = reader.readLine()) != null) {
			temp = line.split(",");

			date1 = new SimpleDateFormat("dd/MM/yyyy").parse(temp[2]);

			bankDetail = new BankDetail(temp[7], Long.parseLong(temp[8]), temp[9]);
			detail = new PensionerDetail(Long.parseLong(temp[0]), temp[1], date1, temp[3], Double.parseDouble(temp[4]),
					Long.parseLong(temp[5]), temp[6], bankDetail);

			alldetails.add(detail);
		}
		
		reader.close();
		
		
		return alldetails;
	}

	
	
}
