package com.cognizant.pensiondetail.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author murali
 *
 */
@AllArgsConstructor
@Setter
@Getter
@EqualsAndHashCode
public class BankDetail {
	
	/** Bank Name */
	private String bankName;
	/** Bank Account Number */
	private long accountNumber;
	/** Bank Type */
	private String bankType;
	

}
