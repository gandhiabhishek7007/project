package com.cognizant.pensiondetail.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.cognizant.pensiondetail.exception.InvalidAadhaarException;
import com.cognizant.pensiondetail.model.PensionerDetail;
import com.cognizant.pensiondetail.repository.PensionRepository;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Murali
 *
 *	Service Fetching Pensioner Details from CSV
 */
@Slf4j
@NoArgsConstructor
@Service
@Configuration
@PropertySource("classpath:messages.properties")
public class PensionDetailsServiceImpl implements PensionDetailsService{
	
	/** Autowired to repo*/
	@Autowired
	private PensionRepository pensionRepo;
	
	/** Autowired to properties file */
	@Autowired
	private Environment env;

	/**
	 *  function to extract details of pensioner from list
	 */
	@Override
	public PensionerDetail findDataByAadhar(final Long aadhar) throws IOException, ParseException, InvalidAadhaarException {
		// TODO Auto-generated method stub
		log.debug(env.getProperty("service.message"));
		final List<PensionerDetail> allDetails = pensionRepo.readAllCsvData();
		PensionerDetail details = null;
		for (PensionerDetail p : allDetails) {
			if (p.getAadharNumber() == aadhar) {
				details = p;
			}
		}
		
		if (details == null) {

			throw new InvalidAadhaarException();
		}
		return details;

	}

}
