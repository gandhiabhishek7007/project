package com.cognizant.pensiondetail.model;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *  @author murali
 *  
 *  Pensioner Details Entity
 */


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PensionerDetail {

	/** Aadhar Number */
	private long aadharNumber;
	/** Pensioner Name */
	private String name;
	/** DOB */
	private Date dateOfBirth;
	/** PAN Number */
	private String pan;
	/** Salary */
	private double salaryEarned;
	/** Allowances */
	private long allowances;
	/** Pension Type */
	private String pensionType;
	/** Bank Details */
	private BankDetail bankDetail;

}

