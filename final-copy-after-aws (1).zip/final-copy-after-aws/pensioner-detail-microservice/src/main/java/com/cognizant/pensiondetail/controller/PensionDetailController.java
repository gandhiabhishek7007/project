package com.cognizant.pensiondetail.controller;

import java.io.IOException;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pensiondetail.exception.InvalidAadhaarException;
import com.cognizant.pensiondetail.model.PensionerDetail;
import com.cognizant.pensiondetail.service.PensionDetailsService;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Pensioner Details controller
 */

@RestController
@NoArgsConstructor
@Slf4j
@Configuration
@PropertySource("classpath:messages.properties")
public class PensionDetailController {

	/**
	 * Autowired to PensionDetailsService Interface
	 */
	@Autowired
	private PensionDetailsService repo;
	
	/**
	 * Autowired Environment for fetching properties
	 */
	@Autowired
	private Environment env;

	/**
	 * Fetch Pensioner Details from Service Layer
	 * 
	 * @param aadhaarNumber
	 * @return - ResponseEntity<PensionerDetail>
	 * @throws IOException @throws ParseException @throws InvalidAadhaarException
	 */
	@PostMapping("/PensionerDetailByAadhaar")
	public ResponseEntity<PensionerDetail> getDetails(@RequestBody final String aadhaarNumber)
			throws IOException, ParseException, InvalidAadhaarException {
		log.debug(env.getProperty("controller.message"));

		PensionerDetail details = null;
		try {
			details = repo.findDataByAadhar(Long.parseLong(aadhaarNumber.replaceAll("\\s", "")));
		} catch (InvalidAadhaarException exception) {
			log.debug(env.getProperty("controller.bad"));
			return new ResponseEntity<PensionerDetail>(details, HttpStatus.BAD_REQUEST);
		}

		log.debug(env.getProperty("controller.return"));
		return new ResponseEntity<PensionerDetail>(details, HttpStatus.OK);
	}
}
