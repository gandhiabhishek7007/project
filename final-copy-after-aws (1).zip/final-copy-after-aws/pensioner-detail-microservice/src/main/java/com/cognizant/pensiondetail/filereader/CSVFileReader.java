package com.cognizant.pensiondetail.filereader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
//import java.io.InputStreamReader;
//import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

/**
 * 
 * Function to Read CSV File
 * @author 841418
 *
 */
@Configuration
@PropertySource("classpath:messages.properties")
public class CSVFileReader {

	/**
	 * Environment to read from property file
	 */
	@Autowired
	private Environment env;

	/** Function to read csv file */
	public BufferedReader getBufferReader() throws IOException {
		final String path = env.getProperty("file.data");

		/** to read from S3 */
		
//		URL url = new URL(path);
//		return new BufferedReader(new InputStreamReader(url.openStream()));

		return new BufferedReader(new FileReader(path));
		
	}
}
