package com.cognizant.pensiondetail.repository;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import com.cognizant.pensiondetail.model.PensionerDetail;

/**
 * 
 * @author Murali
 *
 */

public interface PensionRepository {

	/**
	 * @return List of Pensioner Details from CSV
	 * @throws IOException
	 * @throws ParseException
	 */
	List<PensionerDetail> readAllCsvData() throws IOException, ParseException;

}
