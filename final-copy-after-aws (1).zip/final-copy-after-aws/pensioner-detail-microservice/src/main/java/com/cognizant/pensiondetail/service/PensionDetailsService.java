package com.cognizant.pensiondetail.service;

import java.io.IOException;
import java.text.ParseException;
import com.cognizant.pensiondetail.exception.InvalidAadhaarException;
import com.cognizant.pensiondetail.model.PensionerDetail;

/**
 * 
 * @author murali
 *
 */
public interface PensionDetailsService {
	
	/**
	 * @param id
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 * @throws InvalidAadhaarException
	 */
	PensionerDetail findDataByAadhar(Long aadhar) throws IOException, ParseException, InvalidAadhaarException;

}
