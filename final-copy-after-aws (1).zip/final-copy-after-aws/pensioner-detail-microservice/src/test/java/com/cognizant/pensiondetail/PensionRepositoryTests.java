package com.cognizant.pensiondetail;

import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.cognizant.pensiondetail.filereader.CSVFileReader;
import com.cognizant.pensiondetail.model.PensionerDetail;
import com.cognizant.pensiondetail.repository.PensionRepositoryImpl;

@SpringBootTest
public class PensionRepositoryTests {

	@InjectMocks
	private PensionRepositoryImpl pensionRepositoryImpl;
	
	@Mock
	private Environment env;
	
	@Mock
	private CSVFileReader read;
	
	String path = "data.csv";
	
	@BeforeEach
	void init() throws IOException {
		when(env.getProperty("repo.message")).thenReturn(" ");
		when(read.getBufferReader()).thenReturn(new BufferedReader(new FileReader(path)));
	}
	
	@Test
	void testRepo() throws IOException, ParseException {
		List<PensionerDetail> actual = new ArrayList<>();
		actual = pensionRepositoryImpl.readAllCsvData();
		Assertions.assertNotNull(actual);
	}
}
