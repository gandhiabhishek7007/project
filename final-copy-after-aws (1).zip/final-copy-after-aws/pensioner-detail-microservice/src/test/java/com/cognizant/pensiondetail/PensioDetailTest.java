package com.cognizant.pensiondetail;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.cognizant.pensiondetail.exception.InvalidAadhaarException;
import com.cognizant.pensiondetail.model.BankDetail;
import com.cognizant.pensiondetail.model.PensionerDetail;
import com.cognizant.pensiondetail.repository.PensionRepository;
import com.cognizant.pensiondetail.service.PensionDetailsServiceImpl;

@SpringBootTest
class PensioDetailTest {

	@InjectMocks
	private PensionDetailsServiceImpl service;

	@Mock
	private PensionRepository repo;
	
	@Mock
	private Environment env;

	PensionerDetail detail;

	@BeforeEach
	void init() throws IOException, ParseException {
		List<PensionerDetail> expected = new ArrayList<>();
		BankDetail bankDetail = new BankDetail("HDFC", 12345678, "public");
		Date date = new Date();
		detail = new PensionerDetail(123456789, "murali", date, "BNM12345", Double.parseDouble("50000"),
				Long.parseLong("500"), "family", bankDetail);
		expected.add(detail);
		when(repo.readAllCsvData()).thenReturn(expected);
		when(env.getProperty("service.message")).thenReturn("in the findDatabyAadhar method");
	}

	@Test
	void testfindCorrectDataByAadhar() throws Exception {

		long id = 123456789;
		PensionerDetail actual = service.findDataByAadhar(id);
		Assertions.assertEquals(detail, actual);

	}
	
	@Test()
	void testfindWrongDataByAadhar() throws IOException, ParseException{
		
		long id = 1234567;
		Assertions.assertThrows(InvalidAadhaarException.class, () -> {service.findDataByAadhar(id);});

	}
}
