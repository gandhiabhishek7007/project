package com.cognizant.pensiondetail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.pensiondetail.model.BankDetail;
import com.cognizant.pensiondetail.model.PensionerDetail;

import nl.jqno.equalsverifier.EqualsVerifier;


@SpringBootTest()
class PensionerDetailApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Test
	void testBankDetails() {
		EqualsVerifier.simple().forClass(BankDetail.class).verify();
	}
	
	@Test
	void testPensionerDeatils() {
		EqualsVerifier.simple().forClass(PensionerDetail.class).verify();
	}
	
	@Test
	void testmainMethod() {
		PensionerDetailApplication.main(new String [] {});
	}

}
