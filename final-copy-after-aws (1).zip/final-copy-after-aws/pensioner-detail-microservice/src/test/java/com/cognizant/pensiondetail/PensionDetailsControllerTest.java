package com.cognizant.pensiondetail;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cognizant.pensiondetail.controller.PensionDetailController;
import com.cognizant.pensiondetail.exception.InvalidAadhaarException;
import com.cognizant.pensiondetail.model.BankDetail;
import com.cognizant.pensiondetail.model.PensionerDetail;
import com.cognizant.pensiondetail.service.PensionDetailsService;
@SpringBootTest
class PensionDetailsControllerTest {
    @InjectMocks
	private PensionDetailController PensionDetailController;
    @Mock
    private PensionDetailsService service;
    @Mock
    private Environment env; 
    
    PensionerDetail detail;
    long id;
    
    @BeforeEach
    void init() throws InvalidAadhaarException, IOException, ParseException {
    	List<PensionerDetail> expected=new ArrayList<>();
		BankDetail bankDetail=new BankDetail("HDFC",12345678, "public");
		Date date=new Date();
		detail=new PensionerDetail(123456789,"murali", date,"BNM12345",Double.parseDouble("50000"),Long.parseLong("500"),"family", bankDetail);
		expected.add(detail);
		id=123456789;
		when(env.getProperty("controller.message")).thenReturn("bad request thrown");
		when(env.getProperty("controller.return")).thenReturn("bad request thrown");
		when(env.getProperty("controller.bad")).thenReturn("bad request thrown");
    }
    
	@Test
	void testCorrectControllerTest() throws InvalidAadhaarException, IOException, ParseException{
		when(service.findDataByAadhar(id)).thenReturn(detail);
		ResponseEntity<PensionerDetail> actual= PensionDetailController.getDetails("123456789");
		assertEquals(detail, actual.getBody());
		
	}
	
	@Test
	void testInvalidControllerTest() throws InvalidAadhaarException, IOException, ParseException{
		
		when(service.findDataByAadhar(id)).thenThrow(new InvalidAadhaarException());
		ResponseEntity<PensionerDetail> actual= PensionDetailController.getDetails("123456789");
		assertEquals(HttpStatus.BAD_REQUEST, actual.getStatusCode());
		
	}
	

	
}
