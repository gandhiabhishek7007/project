package com.cognizant.pensionmanagementportal.model;

import java.io.Serializable;

/**
 * 
 * Jwt Response Entity
 *
 */
public class JwtResponse implements Serializable {

	/** SID */
	private static final long serialVersionUID = 1L;
	/** username */
	private final String username;
	/** password */
	private final String jwtToken;

	/** jwt response */
	public JwtResponse(final String username, final String jwtToken) {
		this.username = username;
		this.jwtToken = jwtToken;
	}

	/** get token */
	public String getToken() {
		return this.jwtToken;
	}

	/** get username */
	public String getUsername() {
		return this.username;
	}

}
