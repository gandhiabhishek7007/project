package com.cognizant.pensionmanagementportal.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Pension Detail Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PensionDetail {

	/** Name */
	private String name;
	/** DOB */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfBirth;
	/** PAN Number */
	private String pan;
	/** Self or Family */
	private String selfOrFamilyPension;
	/** Pension Amount */
	private double pensionAmount;

}
