package com.cognizant.pensionmanagementportal.controller;

import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.exchangeserviceproxy.AuthorizationFeign;
import com.cognizant.exchangeserviceproxy.ProcessPensionFeign;
import com.cognizant.pensionmanagementportal.model.JwtRequest;

import com.cognizant.pensionmanagementportal.model.PensionerInput;
import com.cognizant.pensionmanagementportal.model.ProcessPensionInput;
import com.cognizant.pensionmanagementportal.service.PensionManagementPortalServiceImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Aakash Web Portal Controller
 *
 */
@Slf4j
@Controller
public class PensionManagementController {

	/** Feign Authorization */
	@Autowired
	private AuthorizationFeign authFeign;

	/** Feign process pension microservice */
	@Autowired
	private ProcessPensionFeign processPensionFeign;

	/** Service Layer call */
	@Autowired
	private PensionManagementPortalServiceImpl pensionManagementPortalServiceImpl;

	/** Http Session variable */
	private HttpSession session;

	/** Form parameter name to display error messages */
	private final static String messg = "msg";

	/** Home LoginPage */
	@RequestMapping("/")
	public String index(@RequestParam(defaultValue = "") final String msg, final Model model) {
		model.addAttribute(messg, msg);
		return "login";
	}

	/**
	 * Login webpage
	 * 
	 * @param userId, @param password, @param request
	 * @param model,  @return
	 */
	@RequestMapping("/pensionDetail")
	public String login(@RequestParam("username") final String userId, @RequestParam("password") final String password,
			final HttpServletRequest request, final ModelMap model) {
		session = request.getSession();
		log.info(userId);
		log.info(password);
		JwtRequest jwtRequest = new JwtRequest();
		jwtRequest.setUsername(userId);
		jwtRequest.setPassword(password);
		String token = "Bearer ";
		try {
			token += authFeign.getToken(jwtRequest);

		} catch (Exception ex) {
			return "redirect:/?msg=Invalid Credentials";
		}
		session.setAttribute("userId", userId);
		session.setAttribute("token", token);
		log.info(token);
		model.addAttribute("pensionInput", new PensionerInput());
		return "pensionerInput";
	}

	/** Get Pensioner Detail */
	@RequestMapping("/pensionerDetail")
	@HystrixCommand(fallbackMethod = "fallBackpensionDetail")
	public String pensionDetail(@ModelAttribute("pensionInput") final PensionerInput pensionInput,
			final BindingResult result, final ModelMap model) {
		log.debug("type: " + pensionInput.getPensionType());
		ResponseEntity<String> resultString;
		log.debug("string: " + pensionInput.toString());
		try {
			resultString = processPensionFeign.getPensionDetail((String) session.getAttribute("token"), pensionInput);
			
			if (resultString.getStatusCode() == HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS) {
				model.put(messg, "Please Login First");
				return "login";
			}

		} catch (FeignException.BadRequest e) {
			model.put("fillmsg", "Please Enter Correct Details");
			return "pensionerInput";
		}

		log.debug("string: " + resultString);
		Map<String, String> resultMap = pensionManagementPortalServiceImpl.resultTokenGenrationMethod(resultString,
				pensionInput.getAadharNumber());

		model.put("resultMap", resultMap);

		return "pensionerInput";
	}

	/**
	 * fallback method
	 * 
	 * @param pensionInput, @param result, @param model
	 * @return
	 */
	public String fallBackpensionDetail(@ModelAttribute("pensionInput") final PensionerInput pensionInput,
			final BindingResult result, final ModelMap model) {
		model.put(messg, "Service Down. Please Try Again Later!!!");
		return "failure";
	}

	/**
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping("/pensionDisburse")
	public String pensionDisbure(final ModelMap model) {
		// model.addAttribute("aadhar", new Long());
		return "dispersePension";
	}

	/**
	 * 
	 * @param aadharNum
	 * @param pensionerInput
	 * @param model
	 * @return
	 */
	@RequestMapping("/pensionDisbursed")
	@HystrixCommand(fallbackMethod = "fallBackpensionDetailMessage")
	public String pensionDetailMessage(@RequestParam("aadhar") final Long aadharNum,
			@ModelAttribute("pensionInput") final PensionerInput pensionerInput, final ModelMap model) {

		// verifies that Aadhar number is same what was entered in Pensioner Input page.
		Optional<ProcessPensionInput> processPensionInput = pensionManagementPortalServiceImpl
				.processErrorMessage(aadharNum);

		if (!processPensionInput.isPresent()) {

			model.put("fillmsg", "Please Fetch Pensioner Details First.");
			return "pensionerInput";
		}

		ResponseEntity<String> messageString = processPensionFeign
				.getProcessingCode((String) session.getAttribute("token"), processPensionInput.get());

		if (messageString.getStatusCode() == HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS) {
			model.put(messg, "Please Login First");
			return "login";
		}

		String body = pensionManagementPortalServiceImpl.removeDQuotes(messageString.getBody());
		if (body.equalsIgnoreCase("success")) {
			model.put(messg, body);
			return "success";
		}

		model.put(messg, body);
		return "failure";
	}

	/**
	 * fallback method
	 * 
	 * @param aadharNum, @param pensionerInput, @param model
	 * @return
	 */
	public String fallBackpensionDetailMessage(@ModelAttribute("aadhar") final Long aadharNum,
			@ModelAttribute("pensionInput") final PensionerInput pensionerInput, final ModelMap model) {
		model.put(messg, "Pensioner Detail micro service down, Please try again later");
		return "failure";
	}

}
