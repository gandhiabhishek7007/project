package com.cognizant.pensionmanagementportal.service;

import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cognizant.pensionmanagementportal.model.ProcessPensionInput;

/**
 * 
 * web portal Service
 *
 */
public interface PensionManagementPortalService {

	/** returns tokenised parameters */
	Map<String, String> resultTokenGenrationMethod(ResponseEntity<String> resultString, Long aaddharNum);

	/** process error message */
	Optional<ProcessPensionInput> processErrorMessage(Long aadharNum);

	/** removes Double Quotes */
	String removeDQuotes(String string);
}
