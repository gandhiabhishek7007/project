package com.cognizant.pensionmanagementportal.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Process Pension Input Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
public class ProcessPensionInput {

	/** Aadhar Number */
	@Id
	private Long aadharNumber;

	/** Pension AMount */
	private Double pensionAmount;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProcessPensionInput other = (ProcessPensionInput) obj;
		if (pensionAmount == null) {
			if (other.pensionAmount != null)
				return false;
		} else if (!pensionAmount.equals(other.pensionAmount))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pensionAmount == null) ? 0 : pensionAmount.hashCode());
		return result;
	}
	
	
}
