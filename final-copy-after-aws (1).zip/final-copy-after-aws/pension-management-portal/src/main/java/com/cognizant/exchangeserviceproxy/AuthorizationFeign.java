package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.pensionmanagementportal.model.AuthResponse;
import com.cognizant.pensionmanagementportal.model.JwtRequest;

/**
 * 
 * Authorization Feign Client
 * 
 * @author Aakash
 *
 */
@FeignClient(name = "authorization-service", url = "${AUTHORISE_PLOGIN}")
public interface AuthorizationFeign {

	/**
	 * 
	 * @param jwtRequest
	 * @return
	 */
	@PostMapping("/getToken")
	String getToken(@RequestBody JwtRequest jwtRequest);

	/** Request Validation */
	@GetMapping("/validate")
	AuthResponse getValidity(@RequestHeader("Authorization") String token);

}
