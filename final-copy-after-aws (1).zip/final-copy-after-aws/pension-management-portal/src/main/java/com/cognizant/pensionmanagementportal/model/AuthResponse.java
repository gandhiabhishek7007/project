package com.cognizant.pensionmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * Auth Response Entity
 *
 */
@AllArgsConstructor
@Getter
@Setter
public class AuthResponse {

	/** valid or not*/
	private boolean isValid;

}
