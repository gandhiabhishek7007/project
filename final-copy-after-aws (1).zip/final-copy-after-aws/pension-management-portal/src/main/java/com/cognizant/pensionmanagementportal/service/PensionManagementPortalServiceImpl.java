package com.cognizant.pensionmanagementportal.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cognizant.pensionmanagementportal.model.ProcessPensionInput;
import com.cognizant.pensionmanagementportal.repository.PensionManagementRepository;

/**
 * 
 * Service Implementation
 *
 */
@Service
public class PensionManagementPortalServiceImpl implements PensionManagementPortalService {

	/** Autowired to JPA */
	@Autowired
	PensionManagementRepository pensionManagementRepository;

	/**
	 * tokenise String
	 */
	@Override
	public Map<String, String> resultTokenGenrationMethod(final ResponseEntity<String> resultString,
			final Long aaddharNum) {
		Map<String, String> resultMap = new HashMap<String, String>();
		String resultStringBody = resultString.getBody();
		resultStringBody = resultStringBody.substring(1, resultStringBody.length() - 1);

		List<String> listToken = Collections.list(new StringTokenizer(resultStringBody, ",")).stream()
				.map(token -> (String) token).collect(Collectors.toList());
		for (String temp : listToken) {
			String[] keyvalue = temp.split(":");
			keyvalue[0] = keyvalue[0].substring(1, keyvalue[0].length() - 1);

			if (keyvalue[1].charAt(0) == '"') {
				keyvalue[1] = keyvalue[1].substring(1, keyvalue[1].length() - 1);
			}
			resultMap.put(keyvalue[0], keyvalue[1]);
		}
		pensionManagementRepository.deleteAll();
		Double pensionAmount = Double.parseDouble(resultMap.get("pensionAmount"));
		ProcessPensionInput processPensionInput = new ProcessPensionInput(aaddharNum, pensionAmount);
		pensionManagementRepository.save(processPensionInput);
		return resultMap;
	}

	/**
	 * processes error message
	 */
	@Override
	public Optional<ProcessPensionInput> processErrorMessage(final Long aadharNum) {
		return pensionManagementRepository.findById(aadharNum);
	}

	/**
	 * removes double quotes
	 */
	@Override
	public String removeDQuotes(final String string) {
		return string.substring(1, string.length() - 1);
	}

}
