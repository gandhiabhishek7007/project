package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.pensionmanagementportal.model.PensionerInput;
import com.cognizant.pensionmanagementportal.model.ProcessPensionInput;

/**
 * 
 * Feign Client for Pension Process Microservice
 * 
 * @author Aakash
 *
 */
@FeignClient(name = "PensionProcessMicroservice", url = "${PROCESS_PENSION}")
public interface ProcessPensionFeign {

	/** Returns Pension Details */
	@PostMapping("/pps/PensionDetail")
	ResponseEntity<String> getPensionDetail(@RequestHeader(name = "Authorization") String token,
			@RequestBody PensionerInput pensionerInput);

	/** Verifies pension and disburse */
	@PostMapping("/pps/ProcessPension")
	ResponseEntity<String> getProcessingCode(@RequestHeader(name = "Authorization") String token,
			@RequestBody ProcessPensionInput processPensionInput);
}
