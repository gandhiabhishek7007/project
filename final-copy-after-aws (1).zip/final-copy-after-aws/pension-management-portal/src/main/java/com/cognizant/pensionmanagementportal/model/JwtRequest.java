package com.cognizant.pensionmanagementportal.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * JWT Request Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class JwtRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	/** Email for User */
	private String username;
	/** Password */
	private String password;

}
