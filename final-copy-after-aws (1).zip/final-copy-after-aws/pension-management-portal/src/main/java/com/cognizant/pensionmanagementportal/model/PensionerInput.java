package com.cognizant.pensionmanagementportal.model;

import java.sql.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * Pensioner Input Entity
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class PensionerInput {

	/** Name */
	@NotNull(message = "{userName.message}")
	@Size(min = 3, max = 30, message = "{userName.message}")
	private String name;

	/** DOB */
	@NotNull(message = "{userDateOfBirth.message}")
	// @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
	private Date dateOfBirth;

	/** PAN */
	@Size(min = 10, max = 10, message = "{pan.message}")
	private String pan;

	/** Aadhar */
	private long aadharNumber;

	/** Pension Type */
	private String pensionType;
}
