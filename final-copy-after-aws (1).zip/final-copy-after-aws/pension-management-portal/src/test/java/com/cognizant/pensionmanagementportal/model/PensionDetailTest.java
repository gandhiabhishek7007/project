package com.cognizant.pensionmanagementportal.model;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PensionDetailTest {

	@Test
	void testEquals() {
		
		PensionDetail pensionDetail = new PensionDetail();
		pensionDetail.setDateOfBirth(new Date());
		pensionDetail.setName("aakash");
		pensionDetail.setPan("ZXC123");
		pensionDetail.setPensionAmount(500.0);
		pensionDetail.setSelfOrFamilyPension("self");
		
		Assertions.assertEquals(new PensionDetail("aakash", new Date(), "ZXC123", "self", 500.0), pensionDetail);
	}
	
	

}
