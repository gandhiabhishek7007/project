package com.cognizant.pensionmanagementportal.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessPensionInputTest {

	@Test
	void AadharEqual() {
		ProcessPensionInput input = new ProcessPensionInput();
		input.setAadharNumber(Long.parseLong("132465789465"));
		input.setPensionAmount(550.0);
		
		Assertions.assertEquals(Long.parseLong("132465789465"), input.getAadharNumber());
	}
	
	@Test
	void PensionEqual() {
		ProcessPensionInput input = new ProcessPensionInput();
		input.setAadharNumber(Long.parseLong("132465789465"));
		input.setPensionAmount(550.0);	
		Assertions.assertEquals(550.0, input.getPensionAmount());
	}
	
	@Test
	void EqualObjects() {
		ProcessPensionInput input = new ProcessPensionInput();
		input.setAadharNumber(Long.parseLong("132465789465"));
		input.setPensionAmount(550.0);	
		Assertions.assertEquals(input, input);
	}
	

}
