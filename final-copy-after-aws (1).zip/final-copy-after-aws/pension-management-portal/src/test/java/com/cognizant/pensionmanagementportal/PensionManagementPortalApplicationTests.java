package com.cognizant.pensionmanagementportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.pensionmanagementportal.model.PensionDetail;
import com.cognizant.pensionmanagementportal.model.ProcessPensionInput;

import nl.jqno.equalsverifier.EqualsVerifier;

@SpringBootTest
class PensionManagementPortalApplicationTests {
	
	@Test
	void testPensionDeatils() {
		EqualsVerifier.simple().forClass(PensionDetail.class).verify();
	}
	
	@Test
	void testPensionInputDeatils() {
		EqualsVerifier.simple().forClass(ProcessPensionInput.class).verify();
	}

}
