package com.cognizant.pensionmanagementportal.model;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuthResponseTest {
	AuthResponse authResponse = new AuthResponse(true);

	@Test
	public void testIsValid() {
		authResponse.setValid(true);
		assertEquals(authResponse.isValid(), true);
	}

	@Test
	public void testtoString() {
		String s = authResponse.toString();
		assertEquals(authResponse.toString(), s);
	}

}
