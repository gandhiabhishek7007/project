package com.cognizant.pensionmanagementportal.model;

import static org.junit.Assert.assertEquals;

import java.sql.Date;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PensionerInputTest {
	PensionerInput pensioner = new PensionerInput();
	
	@SuppressWarnings("deprecation")
	@Test
	public void pensionerInputAllArgsConstructorTest()
	{
		PensionerInput pensionerInput = new PensionerInput("Admin",new Date(12,12,2020),"ABCDE1234F",123456789,"self");
		assertEquals(pensionerInput.getName(),"Admin");
		assertEquals(pensionerInput.getDateOfBirth(), new Date(12,12,2020));
		assertEquals(pensionerInput.getPan(), "ABCDE1234F");
		assertEquals(pensionerInput.getAadharNumber(), 123456789);
		assertEquals(pensionerInput.getPensionType(), "self");
	}
	
	@Test
	public void pensionerInputNameTest()
	{
		pensioner.setName("Admin");
		assertEquals(pensioner.getName(), "Admin");
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void pensionerInputDateOfBithTest()
	{
		pensioner.setDateOfBirth(new Date(12,12,2020));
		assertEquals(pensioner.getDateOfBirth(), new Date(12,12,2020));
	}
	@Test
	public void pensionerInputAadharNumberTest()
	{
		pensioner.setAadharNumber(123456789);
		assertEquals(pensioner.getAadharNumber(), 123456789);
	}
	
	@Test
	public void pensionerInputPanNumberTest()
	{
		pensioner.setPan("ABCDE1234F");;
		assertEquals(pensioner.getPan(), "ABCDE1234F");
	}
	
	@Test
	public void pensionerInputPensionTypeTest()
	{
		pensioner.setPensionType("self");;
		assertEquals(pensioner.getPensionType(),"self");
	}
	
}
