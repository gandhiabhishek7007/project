package com.cognizant.pensiondisbursement;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cognizant.pensiondisbursement.controller.PensionDisbursementController;
import com.cognizant.pensiondisbursement.model.ProcessPensionInput;
import com.cognizant.pensiondisbursement.model.ProcessPensionResponse;
import com.cognizant.pensiondisbursement.services.PensionDisbursementServiceImpl;

import nl.jqno.equalsverifier.EqualsVerifier;

@SpringBootTest
public class PensionDisbursementControllerTests {

	@InjectMocks
	PensionDisbursementController pensionDisbursementControllerMock;

	@Mock
	PensionDisbursementServiceImpl pensionDisbursementServiceMock;

	@Mock
	Environment env;

	private ProcessPensionInput processPensionInput;
	private ProcessPensionResponse response;

	@BeforeEach
	public void init() {
		processPensionInput = new ProcessPensionInput(Long.valueOf("123456789456"), (double) 43450.0);
		response = new ProcessPensionResponse(10);

		when(env.getProperty("message.10")).thenReturn("Success");
		when(env.getProperty("message.21"))
				.thenReturn("Pension amount calculated is wrong, Please redo the calculation");
		when(env.getProperty("message.25")).thenReturn("Pensioner Detail micro service down, Please try again later");
		when(env.getProperty("message.status")).thenReturn("returned status: ");
		when(env.getProperty("message.serviceDown"))
				.thenReturn("Pensioner-Detail MS is down!! Fallback route enabled. Time:");
		when(env.getProperty("message.aadhar")).thenReturn("Aadhar no: ");
		when(env.getProperty("message.serviceCharge")).thenReturn("service charge: ");
		when(env.getProperty("message.pension")).thenReturn("pension type: ");
		when(env.getProperty("message.pensionCalculationSuccess")).thenReturn(" pension amount calculation success");
		when(env.getProperty("bankType.type1")).thenReturn("public");
		when(env.getProperty("bankType.type2")).thenReturn("private");
		when(env.getProperty("pension.type1")).thenReturn("self");
		when(env.getProperty("pension.type2")).thenReturn("family");

	}

	@Test
	public void testCorrectResponse() {
		when(pensionDisbursementServiceMock.verifyData(processPensionInput)).thenReturn(10);
		Assertions.assertEquals(new ResponseEntity<ProcessPensionResponse>(response, HttpStatus.OK),
				pensionDisbursementControllerMock.pensionDisbursement(processPensionInput));
	}

	@Test
	public void testWrongResponse() {
		response.setPensionStatusCode(21);
		when(pensionDisbursementServiceMock.verifyData(processPensionInput)).thenReturn(21);
		Assertions.assertEquals(new ResponseEntity<ProcessPensionResponse>(response, HttpStatus.OK),
				pensionDisbursementControllerMock.pensionDisbursement(processPensionInput));
	}

	@Test
	public void testProcessPensionResponseEquals() {
		EqualsVerifier.simple().forClass(ProcessPensionResponse.class).verify();
	}
}
