package com.cognizant.pensiondisbursement;

import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.cognizant.exchangeserviceproxy.PensionerDetailsProxy;
import com.cognizant.pensiondisbursement.model.BankDetail;
import com.cognizant.pensiondisbursement.model.PensionerDetail;
import com.cognizant.pensiondisbursement.model.ProcessPensionInput;
import com.cognizant.pensiondisbursement.services.PensionDisbursementServiceImpl;

@SpringBootTest
public class PensionDisbursementServiceTests {

	@InjectMocks
	PensionDisbursementServiceImpl pensionDisbursementServiceMock;

	@Mock
	PensionerDetailsProxy pensionerDetailsProxyMock;

	@Mock
	Environment env;

	private ProcessPensionInput processPensionInput;
	private PensionerDetail pensionerDetail;
	private BankDetail bankDetail;

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void init() {
		processPensionInput = new ProcessPensionInput(Long.valueOf("123456789456"), (double) 43450.0);
		bankDetail = new BankDetail("HDFC", 5000185, "private");
		pensionerDetail = new PensionerDetail(Long.valueOf("123456789456"), "prajesh", new Date("01/02/2018"),
				"BHMAA1234A", 50000.0, 4000, "self", bankDetail);

		when(env.getProperty("message.10")).thenReturn("Success");
		when(env.getProperty("message.21"))
				.thenReturn("Pension amount calculated is wrong, Please redo the calculation");
		when(env.getProperty("message.25")).thenReturn("Pensioner Detail micro service down, Please try again later");
		when(env.getProperty("message.status")).thenReturn("returned status: ");
		when(env.getProperty("message.serviceDown"))
				.thenReturn("Pensioner-Detail MS is down!! Fallback route enabled. Time:");
		when(env.getProperty("message.aadhar")).thenReturn("Aadhar no: ");
		when(env.getProperty("message.serviceCharge")).thenReturn("service charge: ");
		when(env.getProperty("message.pension")).thenReturn("pension type: ");
		when(env.getProperty("message.pensionCalculationSuccess")).thenReturn(" pension amount calculation success");
		when(env.getProperty("bankType.type1")).thenReturn("public");
		when(env.getProperty("bankType.type2")).thenReturn("private");
		when(env.getProperty("pension.type1")).thenReturn("self");
		when(env.getProperty("pension.type2")).thenReturn("family");

	}

	@Test
	public void testCorrectData1() {
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(10, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testCorrectData2() {
		pensionerDetail.getBankDetail().setBankType("public");
		processPensionInput.setPensionAmount(43500.0);
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(10, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testCorrectData3() {
		pensionerDetail.setPensionType("family");
		processPensionInput.setPensionAmount(28450.0);
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(10, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testPublicBankType2() {
		pensionerDetail.getBankDetail().setBankType("public");
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(21, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testWrongCalculatedPensionSelf() {
		processPensionInput.setPensionAmount(29000.0);
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(21, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testWrongCalculatedPensionFamily() {
		pensionerDetail.setPensionType("family");
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(21, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testInvalidPensionType() {
		pensionerDetail.setPensionType("both");
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertEquals(21, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

	@Test
	public void testWrongBank() {
		bankDetail.setBankType("both");
		pensionerDetail.setBankDetail(bankDetail);
		when(pensionerDetailsProxyMock.getPensionerDetailByAadhar("123456789456")).thenReturn(pensionerDetail);
		Assertions.assertNotEquals(10, pensionDisbursementServiceMock.verifyData(processPensionInput));
	}

}
