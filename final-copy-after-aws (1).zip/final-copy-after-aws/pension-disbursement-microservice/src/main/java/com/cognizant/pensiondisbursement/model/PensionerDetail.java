package com.cognizant.pensiondisbursement.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
/**
 * Pensioner Detail Entity
 * 
 * @author 841418
 *
 */
@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
public class PensionerDetail {

	/** Aadhar Number*/
	private long aadharNumber;
	/** Pensioner Name*/
	private String name;
	/** Pensioner DOB*/
	private Date dateOfBirth;
	/** Pensioner PAN*/
	private String pan;
	/** Pensioner Salary*/
	private double salaryEarned;
	/** Pensioner Allowances*/
	private long allowances;
	/** Pensioner Pension Type*/
	private String pensionType;
	/** Pensioner Bank Details*/
	private BankDetail bankDetail;

}
