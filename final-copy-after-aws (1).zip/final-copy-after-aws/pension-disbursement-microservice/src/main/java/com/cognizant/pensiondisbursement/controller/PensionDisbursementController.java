package com.cognizant.pensiondisbursement.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pensiondisbursement.model.ProcessPensionInput;
import com.cognizant.pensiondisbursement.model.ProcessPensionResponse;
import com.cognizant.pensiondisbursement.services.PensionService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * Controller for Pension Disbursement
 * 
 * @author 841418
 *
 */
@RestController
@Slf4j
@Configuration
@PropertySource("classpath:message.properties")
public class PensionDisbursementController {

	/**
	 * Environment to read from properties
	 */
	@Autowired
	private Environment env;

	/**
	 * Service Layer call
	 */
	@Autowired
	private PensionService pensionService;

	/** SUCCESS STATUS CODE*/
	private static final int SUCCESS = 10;
	
	/**
	 * function call to verify and disburse Pension
	 * 
	 * @param processInput
	 * @return
	 */
	@PostMapping(value = "/DisbursePension", produces = MediaType.APPLICATION_JSON_VALUE)
	@HystrixCommand(fallbackMethod = "PensionDisbursement_fallback")
	public ResponseEntity<ProcessPensionResponse> pensionDisbursement(
			@RequestBody final ProcessPensionInput processInput) {

		log.debug(processInput.getAadharNumber() + " " + processInput.getPensionAmount());

		ProcessPensionResponse response = new ProcessPensionResponse(21);

		int statusCode = pensionService.verifyData(processInput);
		if (statusCode == SUCCESS) {
			log.debug(env.getProperty("message.status") + env.getProperty("message.10"));
			response.setPensionStatusCode(statusCode);
			log.debug("set done: " + response.getPensionStatusCode());
		} else {
			log.debug(env.getProperty("message.status") + env.getProperty("message.21"));
		}
		return new ResponseEntity<ProcessPensionResponse>(response, HttpStatus.OK);
	}

	/**
	 * Fallback method for pensionDisbursement Method
	 */
	public ResponseEntity<ProcessPensionResponse> PensionDisbursement_fallback(
			@RequestBody final ProcessPensionInput processInput) {
		log.debug(env.getProperty("message.serviceDown") + new Date());
		final ProcessPensionResponse response = new ProcessPensionResponse(25);
		log.debug(env.getProperty("message.status") + env.getProperty("message.25"));
		return new ResponseEntity<ProcessPensionResponse>(response, HttpStatus.SERVICE_UNAVAILABLE);
	}
}
