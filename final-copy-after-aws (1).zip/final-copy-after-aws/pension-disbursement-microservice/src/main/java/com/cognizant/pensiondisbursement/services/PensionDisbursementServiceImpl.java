package com.cognizant.pensiondisbursement.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.cognizant.exchangeserviceproxy.PensionerDetailsProxy;
import com.cognizant.pensiondisbursement.model.PensionerDetail;
import com.cognizant.pensiondisbursement.model.ProcessPensionInput;

import lombok.extern.slf4j.Slf4j;

/**
 * Disburse Service Implementation
 * 
 * @author 841418
 *
 */
@Service
@Slf4j
@Configuration
@PropertySource("classpath:message.properties")
public class PensionDisbursementServiceImpl implements PensionService {

	/**
	 * Environment to read properties
	 */
	@Autowired
	private Environment env;

	/**
	 * Autowired to Feign Client
	 */
	@Autowired
	private PensionerDetailsProxy pensionerProxy;
	
	
	/** public bank charges */
	private static final double PUBLIC_BCHARGE = 500.0;
	
	/** public bank charges */
	private static final double PRIVATE_BCHARGE = 550.0;
	
	/**
	 * Implements verify Data method of Pension Disbursement Service
	 * 
	 */
	@Override
	public int verifyData(final ProcessPensionInput processInput) {

		log.debug(env.getProperty("message.aadhar") + processInput.getAadharNumber().toString());

		final PensionerDetail pensionerDetail = pensionerProxy
				.getPensionerDetailByAadhar(Long.toString(processInput.getAadharNumber()));

		Double serviceCharge;
		final String BankType = pensionerDetail.getBankDetail().getBankType();
		if (BankType.equalsIgnoreCase(env.getProperty("bankType.type1"))) {
			serviceCharge = PUBLIC_BCHARGE;
		} else if (BankType.equalsIgnoreCase(env.getProperty("bankType.type2"))) {
			serviceCharge = PRIVATE_BCHARGE;
		} else {
			return 21;
		}

		log.debug(env.getProperty("message.pension") + pensionerDetail.getPensionType());
		if (pensionerDetail.getPensionType().equalsIgnoreCase(env.getProperty("pension.type1"))) {

			if (processInput.getPensionAmount() == 0.8 * pensionerDetail.getSalaryEarned()
					+ pensionerDetail.getAllowances() - serviceCharge) {
				log.debug(env.getProperty("pension.type2") + env.getProperty("message.pensionCalculationSuccess"));
				return 10;
			}
		}

		else if (pensionerDetail.getPensionType().equalsIgnoreCase(env.getProperty("pension.type2"))) {
			if (processInput.getPensionAmount() == 0.5 * pensionerDetail.getSalaryEarned()
					+ pensionerDetail.getAllowances() - serviceCharge) {
				log.debug(env.getProperty("pension.type2") + env.getProperty("message.pensionCalculationSuccess"));
				return 10;
			}
		}

		return 21;
	}

}
