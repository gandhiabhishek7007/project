package com.cognizant.pensiondisbursement.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Response of this MS
 * 
 * @author 841418
 *
 */
@Setter
@Getter
@AllArgsConstructor
@EqualsAndHashCode
@NoArgsConstructor
public class ProcessPensionResponse {

	/** Return Status Code*/
	private int pensionStatusCode;

}
