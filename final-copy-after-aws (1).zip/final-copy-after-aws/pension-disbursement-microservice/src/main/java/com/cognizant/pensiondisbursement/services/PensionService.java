package com.cognizant.pensiondisbursement.services;

import com.cognizant.pensiondisbursement.model.ProcessPensionInput;

/**
 * 
 * Interface for Disburse Service
 * @author 841418
 *
 */
public interface PensionService {

	/**  Function to verify Data */
	int verifyData(ProcessPensionInput processPension);

}
