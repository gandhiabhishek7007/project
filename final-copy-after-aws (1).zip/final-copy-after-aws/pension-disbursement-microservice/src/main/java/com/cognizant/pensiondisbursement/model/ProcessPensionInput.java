package com.cognizant.pensiondisbursement.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Process Pension MS Input
 * 
 * @author 841418
 *
 */
@Getter
@Setter
@EqualsAndHashCode
@ToString
@AllArgsConstructor
public class ProcessPensionInput {

	/**  Aadhar Number*/
	private Long aadharNumber;
	/** Pension Amount*/
	private Double pensionAmount;

}
