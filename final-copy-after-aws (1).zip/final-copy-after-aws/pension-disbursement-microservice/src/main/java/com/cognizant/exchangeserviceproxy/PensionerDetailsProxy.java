package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cognizant.pensiondisbursement.model.PensionerDetail;

/**
 * Feign Client to fetch from PensionerDetail MS
 * 
 * @author 841418
 *
 */

@FeignClient(name = "Pensioner-detail", url = "${PENSIONER_DETAIL}")
public interface PensionerDetailsProxy {

	/**
	 * Get Mapping Body Size giving 405 error for feign client.
	 * 
	 * @param aadhar
	 * @return
	 */
	@PostMapping(value = "/pds/PensionerDetailByAadhaar", produces = MediaType.APPLICATION_JSON_VALUE)
	PensionerDetail getPensionerDetailByAadhar(@RequestBody String aadhar);
}
