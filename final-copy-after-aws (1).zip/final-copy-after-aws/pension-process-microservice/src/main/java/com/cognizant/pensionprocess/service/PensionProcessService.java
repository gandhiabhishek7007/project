package com.cognizant.pensionprocess.service;

import com.cognizant.pensionprocess.model.PensionDetail;
import com.cognizant.pensionprocess.model.PensionerInput;
import com.cognizant.pensionprocess.model.ProcessPensionInput;

/**
 * 
 * Interface for Pension process MS
 *
 */
public interface PensionProcessService {

	/**
	 * calculates pension and fetches pensioner details
	 * 
	 * @param pensionerInput
	 * @return
	 */
	PensionDetail pensionCalculate(PensionerInput pensionerInput);

	/**
	 * verifies pension amount and disburse pension
	 * 
	 * @param processPensionInput
	 * @return
	 */
	int responseCode(ProcessPensionInput processInput);

}
