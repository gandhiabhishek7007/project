package com.cognizant.pensionprocess.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Process pension Input Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class ProcessPensionInput {
	/** Aadhar Number*/
	private Long aadharNumber;
	/** Pension Amount*/
	private Double pensionAmount;
}
