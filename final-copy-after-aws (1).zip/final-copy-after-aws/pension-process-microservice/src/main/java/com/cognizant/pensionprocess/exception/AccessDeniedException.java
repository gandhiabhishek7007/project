package com.cognizant.pensionprocess.exception;

/**
 * Access Denied Exception
 */
public class AccessDeniedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
