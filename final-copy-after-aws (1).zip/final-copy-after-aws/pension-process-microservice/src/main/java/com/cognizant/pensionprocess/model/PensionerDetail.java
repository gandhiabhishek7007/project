package com.cognizant.pensionprocess.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Pension Detail Entity
 *
 */
@Getter
@Setter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class PensionerDetail {

	/**  Aadhar Number */
	private long aadharNumber;
	/**  Name */
	private String name;
	/**  DOB */
	private Date dateOfBirth;
	/**  PAN */
	private String pan;
	/**  Salary*/
	private double salaryEarned;
	/**  Allowances*/
	private long allowances;
	/**  Pension Type*/
	private String pensionType;
	/**  Bank Detail*/
	private BankDetail bankDetail;

}
