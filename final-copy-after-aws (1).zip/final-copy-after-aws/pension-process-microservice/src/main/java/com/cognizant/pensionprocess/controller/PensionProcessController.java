package com.cognizant.pensionprocess.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pensionprocess.exception.PensionerDetailNotFoundException;
import com.cognizant.pensionprocess.model.AuthResponse;
import com.cognizant.pensionprocess.model.PensionDetail;
import com.cognizant.pensionprocess.model.PensionerInput;
import com.cognizant.pensionprocess.model.ProcessPensionInput;
import com.cognizant.pensionprocess.service.PensionProcessServiceImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestHeader;

/**
 * 
 * Controller for pension process ms
 *
 */

@RestController
@Configuration
@PropertySource("classpath:messages.properties")
@Slf4j
public class PensionProcessController {

	/**
	 * Environment to fetch properties
	 */
	@Autowired
	private Environment env;

	/**
	 * Service Layer Call
	 */
	@Autowired
	private PensionProcessServiceImpl pensionService;

	/** Variable for Authorization */
	private final static String authorization = "Authorization";

	/**
	 * post request to fetch pension details
	 * 
	 * @param token
	 * @param pensionerInput
	 * @return
	 * @throws PensionerDetailNotFoundException
	 */
	@PostMapping("/PensionDetail")
	@HystrixCommand(fallbackMethod = "getFallbackPensionDetail")
	public ResponseEntity<?> getPensionDetail(@RequestHeader(name = authorization) final String token,
			@RequestBody final PensionerInput pensionerInput) {
		log.info("controller started");
		log.debug("date: " + pensionerInput.getDateOfBirth());
		log.debug(token);

		AuthResponse valid = pensionService.checkPermission(token);
		if (!valid.isValid()) {
			String response = "40";
			return new ResponseEntity<String>(env.getProperty(response), HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS);
		}

		log.debug("authorised");
		try {
			PensionDetail pensionDetail = pensionService.pensionCalculate(pensionerInput);

			log.debug(pensionDetail.toString());
			return new ResponseEntity<PensionDetail>(pensionDetail, HttpStatus.OK);
		} catch (PensionerDetailNotFoundException exception) {
			log.debug("bad request");
			String response = "27";
			return new ResponseEntity<String>(env.getProperty(response), HttpStatus.BAD_REQUEST);
		}

	}

	/** Fallback for pension calculation */
	public ResponseEntity<?> getFallbackPensionDetail(@RequestHeader(name = authorization) final String token,
			@RequestBody final PensionerInput pensionerInput) {
		log.debug("service unavailable");
		String response = "25";
		return new ResponseEntity<String>(env.getProperty(response), HttpStatus.SERVICE_UNAVAILABLE);
	}

	/** Controller for pension disbursement */
	@PostMapping("/ProcessPension")
	@HystrixCommand(fallbackMethod = "getFallbackProcessingCode")
	public ResponseEntity<?> getProcessingCode(@RequestHeader(name = authorization) final String token,
			@RequestBody final ProcessPensionInput processInput) {

		AuthResponse valid = pensionService.checkPermission(token);
		if (!valid.isValid()) {
			String response = "40";
			return new ResponseEntity<String>(env.getProperty(response), HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS);
		}

		int statusCode = pensionService.responseCode(processInput);
		String response = Integer.toString(statusCode);

		return new ResponseEntity<String>(env.getProperty(response), HttpStatus.OK);
	}

	/** Fallback for pension disbursement */
	public ResponseEntity<?> getFallbackProcessingCode(@RequestHeader(name = authorization) final String token,
			@RequestBody final ProcessPensionInput processInput) {
		String response = "30";
		return new ResponseEntity<String>(env.getProperty(response), HttpStatus.SERVICE_UNAVAILABLE);
	}
}
