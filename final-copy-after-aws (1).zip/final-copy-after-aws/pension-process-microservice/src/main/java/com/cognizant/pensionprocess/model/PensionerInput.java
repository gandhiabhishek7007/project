package com.cognizant.pensionprocess.model;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


/**
 * 
 * Pensioner Input Entity
 *
 */
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class PensionerInput {
	/** Name */
	private String name;
	/** DOB */
	private Date dateOfBirth;
	/** PAN */
	private String pan;
	/** Aadhar Number */
	private long aadharNumber;
	/** pension Type */
	private String pensionType;
}
