package com.cognizant.pensionprocess.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Auth Response Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuthResponse {

	/** valid or not */
	private boolean isValid;

}
