package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.pensionprocess.model.AuthResponse;
/**
 *
 * 
 * Feign CLient for AUthentication
 *
 */
@FeignClient(name = "authorization-service", url = "${AUTHORISE_PLOGIN}")
public interface AuthClient {

	/**
	 * Requests validity
	 * @param token
	 * @return
	 */
	@GetMapping("/auth/validate")
		ResponseEntity<AuthResponse> getValidity(@RequestHeader("Authorization") String token) ;

}
