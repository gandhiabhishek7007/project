package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.cognizant.pensionprocess.model.PensionerDetail;

/**
 * 
 * Feign Client for Pensioner Detail MS 
 *
 */
@FeignClient(name = "Pensioner-detail", url = "${PENSIONER_DETAIL}")
public interface PensionerDetailExchangeServiceProxy {

	/**
	 * requests Pensioner Details
	 * @param aadharNumber
	 * @return
	 */
	@PostMapping("/pds/PensionerDetailByAadhaar")
		ResponseEntity<PensionerDetail> getPensionerDetailByAadhaar(@RequestBody String aadharNumber);

}
