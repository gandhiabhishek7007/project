package com.cognizant.pensionprocess.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.cognizant.exchangeserviceproxy.PensionDisbursementExchangeServiceProxy;
import com.cognizant.exchangeserviceproxy.PensionerDetailExchangeServiceProxy;
import com.cognizant.pensionprocess.exception.AccessDeniedException;
import com.cognizant.pensionprocess.exception.PensionerDetailNotFoundException;
import com.cognizant.pensionprocess.model.AuthResponse;
import com.cognizant.pensionprocess.model.PensionDetail;
import com.cognizant.pensionprocess.model.PensionerDetail;
import com.cognizant.pensionprocess.model.PensionerInput;
import com.cognizant.pensionprocess.model.ProcessPensionInput;
import com.cognizant.pensionprocess.model.ProcessPensionResponse;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.cognizant.exchangeserviceproxy.AuthClient;

/**
 * Service Implementation
 *
 */
@Service
@Slf4j
@Configuration
@PropertySource("classpath:messages.properties")
public class PensionProcessServiceImpl implements PensionProcessService {

	/** Environment to fetch properties */
	@Autowired
	private Environment env;

	/** pensioner detail proxy */
	@Autowired
	private PensionerDetailExchangeServiceProxy pensionerDetailProxy;

	/** pension disbursement proxy */
	@Autowired
	private PensionDisbursementExchangeServiceProxy pensionDisbursementProxy;

	/** Auth client proxy */
	@Autowired
	private AuthClient authClient;

	/** public bank charge */
	final int PUBLIC_BANK_CHARGE = 500;

	/** public bank charge */
	final int PRIVATE_BANK_CHARGE = 550;

	/** Service to calculate pension and fetch pensioner details */
	public AuthResponse checkPermission(final String token) {
		ResponseEntity<AuthResponse> authResponse = new ResponseEntity<AuthResponse>(HttpStatus.UNAUTHORIZED);
		try {
			authResponse = authClient.getValidity(token);

			if (!authResponse.getBody().isValid()) {
				throw new AccessDeniedException();
			}
		} catch (Exception e) {
			throw new AccessDeniedException();
		}
		return authResponse.getBody();
	}

	// Service for Fetching Pension Details
	@Override
	public PensionDetail pensionCalculate(final PensionerInput pensionerInput) {

		ResponseEntity<PensionerDetail> pensionerDetailEntity = null;

		// checks for Http Response 400
		try {
			log.debug("" + pensionerInput.getAadharNumber());
			pensionerDetailEntity = pensionerDetailProxy
					.getPensionerDetailByAadhaar(Long.toString(pensionerInput.getAadharNumber()));

			if (pensionerDetailEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
				throw new PensionerDetailNotFoundException();
			}
		} catch (FeignException.BadRequest e) {
			throw new PensionerDetailNotFoundException();
		}

		PensionerDetail pensionerDetail = pensionerDetailEntity.getBody();

		// Time Zone Correction

		Calendar cal = Calendar.getInstance();
		cal.setTime(pensionerInput.getDateOfBirth());
		cal.add(Calendar.MINUTE, -330);
		Date date = cal.getTime();

		pensionerInput.setDateOfBirth(date);

		if (!pensionerInput.getName().equals(pensionerDetail.getName())
				|| !pensionerInput.getPan().equals(pensionerDetail.getPan())
				|| !pensionerInput.getPensionType().equals(pensionerDetail.getPensionType())
				|| !pensionerInput.getDateOfBirth().equals(pensionerDetail.getDateOfBirth())) {
			throw new PensionerDetailNotFoundException();
		}

		double salary = pensionerDetail.getSalaryEarned();
		double allowances = pensionerDetail.getAllowances();
		String pensionType = pensionerDetail.getPensionType();
		String bankType = pensionerDetail.getBankDetail().getBankType();
		double pensionAmount = 0;
		double bankCharges = 0;

		log.debug(Double.toString(salary));
		log.debug(Double.toString(allowances));
		log.debug(pensionType);
		log.debug(bankType);
		log.debug(env.getProperty("bank.type2"));

		if (bankType.equalsIgnoreCase(env.getProperty("bank.type1"))) {
			bankCharges = PUBLIC_BANK_CHARGE;
		} else if (bankType.equalsIgnoreCase(env.getProperty("bank.type2"))) {
			bankCharges = PRIVATE_BANK_CHARGE;
		} else {
			throw new PensionerDetailNotFoundException();
		}
		log.debug(Double.toString(bankCharges));

		if (pensionType.equalsIgnoreCase(env.getProperty("pension.type1"))) {
			pensionAmount = 0.8 * salary + allowances - bankCharges;
		} else if (pensionType.equalsIgnoreCase(env.getProperty("pension.type2"))) {
			pensionAmount = 0.5 * salary + allowances - bankCharges;
		} else {
			throw new PensionerDetailNotFoundException();
		}
		log.debug(env.getProperty("message.pension.amount") + pensionAmount);

		return new PensionDetail(pensionerDetail.getName(), pensionerDetail.getDateOfBirth(),
				pensionerDetail.getPan(), pensionerDetail.getPensionType(), pensionAmount);

	}

	// Service for disburse Pension
	@Override
	public int responseCode(final ProcessPensionInput processInput) {

		ResponseEntity<ProcessPensionResponse> processingCode = pensionDisbursementProxy
				.getResponseCode(processInput);

		ProcessPensionResponse response = processingCode.getBody();
		log.debug(env.getProperty("message.status") + response.getPensionStatusCode());
		return response.getPensionStatusCode();

	}

}
