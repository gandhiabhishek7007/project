package com.cognizant.pensionprocess.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * Pension Detail Entity
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
@EqualsAndHashCode
public class PensionDetail {

	/** Pensioner Name */
	private String name;
	/** Date of Birth*/
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd/MM/yyyy")
	private Date dateOfBirth;
	/** Pan Card*/
	private String pan;
	/** Self or Family pension Type*/
	private String selfOrFamilyPension;
	
	/** pension Amount */
	private double pensionAmount;	

}
