package com.cognizant.pensionprocess.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Bank Detail Entity
 *
 */
@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class BankDetail {

	/** Bank Name */
	private String bankName;
	/** Account Number */
	private long accountNumber;
	/** Bank Type */
	private String bankType;
}
