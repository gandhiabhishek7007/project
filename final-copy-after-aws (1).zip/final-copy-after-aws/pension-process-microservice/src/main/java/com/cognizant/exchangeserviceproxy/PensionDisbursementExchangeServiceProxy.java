package com.cognizant.exchangeserviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.cognizant.pensionprocess.model.ProcessPensionInput;
import com.cognizant.pensionprocess.model.ProcessPensionResponse;

/**
 * 
 * Feign Client for Pension Disbursement MS
 *
 */
@FeignClient(name = "PernsionDisbursementMicroservice", url = "${PENSION_DISBURSE}")
public interface PensionDisbursementExchangeServiceProxy {
	
	/**
	 * Request response code
	 * @param processPensionInput
	 * @return
	 */
	@PostMapping(value = "/pdis/DisbursePension", produces = MediaType.APPLICATION_JSON_VALUE)
		ResponseEntity<ProcessPensionResponse> getResponseCode(@RequestBody ProcessPensionInput processInput);

}
