package com.cognizant.authorizationservice.model;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class CustomErrorResponse {
	private LocalDateTime timestamp;
	private HttpStatus status;
	private String reason;
	private String message;

}
