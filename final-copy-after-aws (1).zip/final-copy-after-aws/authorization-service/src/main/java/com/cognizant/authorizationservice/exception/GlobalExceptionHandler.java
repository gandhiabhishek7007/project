package com.cognizant.authorizationservice.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cognizant.authorizationservice.model.CustomErrorResponse;


@RestControllerAdvice
public class GlobalExceptionHandler {

	
	@ExceptionHandler({ UserNotFoundException.class })
	public ResponseEntity<CustomErrorResponse> handlePensionerNotFoundException(UserNotFoundException ex) {

		CustomErrorResponse response = new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setMessage(ex.getMessage());
		response.setStatus(HttpStatus.FORBIDDEN);
		response.setReason("Invalid Credentials");

		return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);

	}
	
}
