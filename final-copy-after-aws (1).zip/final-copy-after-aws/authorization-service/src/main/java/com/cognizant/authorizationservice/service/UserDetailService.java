package com.cognizant.authorizationservice.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.authorizationservice.exception.UserNotFoundException;
import com.cognizant.authorizationservice.model.Pensioner;
import com.cognizant.authorizationservice.repository.UserRepository;

@Service
public class UserDetailService implements UserDetailsService {

	@Autowired
	private UserRepository pensionerRepository;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Pensioner pensioner = pensionerRepository.findByEmail(email);
		if (pensioner == null) {
			throw new UserNotFoundException("Wrong Email/Password.");
		}
		return new User(pensioner.getEmail(), pensioner.getPassword(), new ArrayList());
	}
}
