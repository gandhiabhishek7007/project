package com.cognizant.authorizationservice.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.authorizationservice.model.Pensioner;
import com.cognizant.authorizationservice.repository.UserRepository;

@SpringBootTest
public class UserDetailServiceTest {
	UserDetails userdetails;

	@InjectMocks
	UserDetailService userDetailService;

	@Mock
	UserRepository userservice;

	@Test
	public void loadUserByUsernameTest() {

		Pensioner user1 = new Pensioner(10, "pensioner", "pensioner", "pensioner@mail.com");
		when(userservice.findByEmail("pensioner@mail.com")).thenReturn(user1);
		UserDetails loadUserByUsername2 = userDetailService.loadUserByUsername("pensioner@mail.com");
		assertEquals(user1.getEmail(), loadUserByUsername2.getUsername());

	}

}
