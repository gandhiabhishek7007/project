package com.cognizant.authorizationservice.model;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

@SpringBootTest
public class CustomErrorResponseTest {

	CustomErrorResponse cer = new CustomErrorResponse();

	@Test
	public void testMessage() {
		cer.setMessage("Invalid");
		assertEquals(cer.getMessage(), "Invalid");
	}

	@Test
	public void testReason() {
		cer.setReason("Invalid");
		assertEquals(cer.getReason(), "Invalid");
	}

	@Test
	public void testHttpStatus() {
		cer.setStatus(HttpStatus.FORBIDDEN);
		assertEquals(cer.getStatus(), cer.getStatus());
	}

	@Test
	public void testToString() {
		String string = cer.toString();
		assertEquals(cer.toString(), string);
	}

	
}
