README:

	ORDER OF MICROSERVICE TO START:
		1. authorization-service
		2. pensioner-detail-microservice
		3. pension-disbursement-microservice
		4. pension-process-microservice
		5. pension-management-portal (Web Portal)
		
	URL to access services on local system:
		1. localhost:8771/auth  <-- authorization-service
		2. localhost:6010/pds   <-- pensioner-detail-microservice
		3. localhost:6020/pdis  <-- pension-disbursement-microservice
		4. localhost:7000/pps   <-- pension-process-microservice
		5. localhost:8770/pms   <-- pension-management-portal (Web Portal)
		
EXECUTION STEPS:

	1. START all microservices.
	
	2. Go to http://localhost:8770/pms/ 
	
	3. Enter username and password to Login:
			username: pensioner@mail.com
			password: pensioner
			
	4. Enter Pensioner Details to fetch Details and Click Fetch:
			name: satyam
			dob: 12-mar-1999
			pan: ZXCVB1234N
			aadhar No. : 123456789123
			type: self
			
	5. Details will be fetched in right foem. Click disburse pension to disburse.
	
	6. Enter same aadhar No. to verify. 
		aadhar No. 123456789123
		
	8. If the data is correct, success page will load.
	
	IMPORTANT NOTE:
	
		1. If any data is entered wrong, you will be redirected to previous page for correction.
		
		2. If any microservice is down, error will be displayed.
		
		4. Database id fetched from csv file located in pensioner-detail-microservice. Please make changes there if you want to add or remove data.
		
		5. H2 database is configured in pension-management-portal. You can access it from:
				 http://localhost:8770/pms/h2-console
				 
				 DRIVER CLASS: org.h2.Driver
				 JDBC URL: jdbc:h2:mem:process_pension
				 USERNAME: sa
				 PASSWORD: password
		